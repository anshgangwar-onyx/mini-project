
import React from 'react';

interface VoiceIndicatorProps {
  status: 'listening' | 'speaking' | 'processing' | 'idle';
}

const VoiceIndicator: React.FC<VoiceIndicatorProps> = ({ status }) => {
  const getPulseColor = () => {
    switch (status) {
      case 'listening': return 'bg-emerald-500';
      case 'speaking': return 'bg-blue-500';
      case 'processing': return 'bg-amber-500';
      default: return 'bg-slate-600';
    }
  };

  const getLabel = () => {
    switch (status) {
      case 'listening': return 'Listening...';
      case 'speaking': return 'Interviewer is Speaking';
      case 'processing': return 'Analyzing Response';
      default: return 'Waiting';
    }
  };

  return (
    <div className="flex flex-col items-center gap-6 py-10">
      <div className="relative">
        {status !== 'idle' && (
          <div className={`absolute inset-0 rounded-full animate-ping opacity-25 ${getPulseColor()}`} />
        )}
        <div className={`w-32 h-32 rounded-full flex items-center justify-center border-4 border-slate-800 transition-colors duration-500 ${getPulseColor()}`}>
           <svg className="w-12 h-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
           </svg>
        </div>
      </div>
      <div className="text-xl font-medium tracking-wide text-slate-200 uppercase animate-pulse">
        {getLabel()}
      </div>
    </div>
  );
};

export default VoiceIndicator;
