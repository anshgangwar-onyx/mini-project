
import React from 'react';
import { EvaluationReport } from '../types';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';

interface AssessmentReportProps {
  report: EvaluationReport;
}

const AssessmentReport: React.FC<AssessmentReportProps> = ({ report }) => {
  const chartData = [
    { subject: 'Technical', A: report.technicalKnowledgeScore * 10, fullMark: 100 },
    { subject: 'Problem Solving', A: report.problemSolvingScore * 10, fullMark: 100 },
    { subject: 'Communication', A: report.communicationScore * 10, fullMark: 100 },
    { subject: 'Confidence', A: report.confidenceLevel * 10, fullMark: 100 },
    { subject: 'Industry Readiness', A: report.industryReadiness * 10, fullMark: 100 },
  ];

  return (
    <div className="w-full max-w-6xl mx-auto space-y-8 pb-20 animate-in fade-in duration-1000">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 glass p-8 rounded-3xl">
        <div>
          <h1 className="text-4xl font-extrabold text-white mb-2">Interview Outcome</h1>
          <p className="text-slate-400 text-lg">Comprehensive Career Readiness Analysis</p>
        </div>
        <div className={`px-8 py-4 rounded-2xl text-2xl font-bold border-2 ${
          report.hiringRecommendation.includes('Hire') ? 'border-emerald-500 text-emerald-400 bg-emerald-500/10' : 'border-amber-500 text-amber-400 bg-amber-500/10'
        }`}>
          {report.hiringRecommendation}
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Radar Chart Section */}
        <div className="lg:col-span-1 glass p-8 rounded-3xl flex flex-col items-center">
          <h3 className="text-xl font-semibold mb-6">Competency Map</h3>
          <div className="w-full h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
                <PolarGrid stroke="#475569" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 12 }} />
                <Radar
                  name="Candidate"
                  dataKey="A"
                  stroke="#10b981"
                  fill="#10b981"
                  fillOpacity={0.6}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-4 w-full">
            <div className="p-4 bg-slate-800/50 rounded-2xl text-center">
              <div className="text-slate-400 text-sm">Resume Score</div>
              <div className="text-2xl font-bold text-white">{report.resumeScore}%</div>
            </div>
            <div className="p-4 bg-slate-800/50 rounded-2xl text-center">
              <div className="text-slate-400 text-sm">ATS Match</div>
              <div className="text-2xl font-bold text-white">{report.atsCompatibility}%</div>
            </div>
          </div>
        </div>

        {/* Key Strengths & Improvements */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="glass p-8 rounded-3xl">
            <h3 className="text-xl font-semibold text-emerald-400 mb-6 flex items-center gap-2">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Core Strengths
            </h3>
            <ul className="space-y-4">
              {report.strengths.map((s, i) => (
                <li key={i} className="flex gap-3 text-slate-300">
                  <span className="text-emerald-500">•</span> {s}
                </li>
              ))}
            </ul>
          </div>
          <div className="glass p-8 rounded-3xl">
            <h3 className="text-xl font-semibold text-amber-400 mb-6 flex items-center gap-2">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Areas to Improve
            </h3>
            <ul className="space-y-4">
              {report.areasToImprove.map((a, i) => (
                <li key={i} className="flex gap-3 text-slate-300">
                  <span className="text-amber-500">•</span> {a}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* Improvement Plan */}
        <div className="glass p-8 rounded-3xl lg:col-span-2">
          <h3 className="text-xl font-semibold mb-6 text-blue-400">3-Month Action Plan</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {report.improvementPlan3Month.map((step, i) => (
              <div key={i} className="p-4 bg-slate-800/30 border border-slate-700 rounded-2xl flex gap-4">
                <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex-shrink-0 flex items-center justify-center font-bold">
                  {i + 1}
                </div>
                <p className="text-slate-300 text-sm leading-relaxed">{step}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Certifications & Roles */}
        <div className="space-y-8">
          <div className="glass p-8 rounded-3xl">
            <h3 className="text-xl font-semibold mb-4 text-indigo-400">Recommended Certs</h3>
            <div className="flex flex-wrap gap-2">
              {report.recommendedCertifications.map((c, i) => (
                <span key={i} className="px-3 py-1 bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 rounded-lg text-sm">
                  {c}
                </span>
              ))}
            </div>
          </div>
          <div className="glass p-8 rounded-3xl">
            <h3 className="text-xl font-semibold mb-4 text-purple-400">Target Roles</h3>
            <div className="flex flex-wrap gap-2">
              {report.suitableJobRoles.map((r, i) => (
                <span key={i} className="px-3 py-1 bg-purple-500/10 text-purple-300 border border-purple-500/30 rounded-lg text-sm">
                  {r}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssessmentReport;
