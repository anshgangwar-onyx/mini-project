
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage, Blob } from '@google/genai';
import { ResumeData, InterviewExchange } from '../types';
import VoiceIndicator from './VoiceIndicator';

interface InterviewSessionProps {
  resume: ResumeData;
  onInterviewEnd: (transcripts: InterviewExchange[]) => void;
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const InterviewSession: React.FC<InterviewSessionProps> = ({ resume, onInterviewEnd }) => {
  const [status, setStatus] = useState<'listening' | 'speaking' | 'processing' | 'idle'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [isEnding, setIsEnding] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const transcriptsRef = useRef<InterviewExchange[]>([]);
  const currentQRef = useRef<string>("");
  const currentARef = useRef<string>("");
  const sessionRef = useRef<any>(null);

  const startSession = useCallback(async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
      
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputAudioContext;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const systemInstruction = `
        You are a senior corporate interviewer conducting a professional assessment for a ${resume.seniority} level ${resume.domain} role.
        The candidate's resume includes these skills: ${resume.skills.join(", ")}.
        
        RULES:
        1. Start by asking for a professional introduction.
        2. Ask questions based on the resume and industry-standard technical skills.
        3. BE CONCISE. Responses must be max 2-3 sentences. No long lectures.
        4. Adjust difficulty dynamically: probe deeper if the candidate is vague, increase complexity if strong.
        5. DO NOT reveal scores or give direct feedback during the interview.
        6. Use a professional, calm, human-like tone. Avoid being robotic.
        7. If you sense the interview should conclude (after ~5-7 questions), provide a professional closing and say "The interview session is now complete. Thank you for your time."
      `;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const source = inputAudioContext.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob: Blob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Audio handling
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              setStatus('speaking');
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
              const source = outputAudioContext.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputAudioContext.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setStatus('listening');
              });
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }

            // Transcription handling
            if (message.serverContent?.outputTranscription) {
              currentQRef.current += message.serverContent.outputTranscription.text;
              if (currentQRef.current.toLowerCase().includes("interview session is now complete")) {
                setIsEnding(true);
              }
            } else if (message.serverContent?.inputTranscription) {
              currentARef.current += message.serverContent.inputTranscription.text;
            }

            if (message.serverContent?.turnComplete) {
              if (currentQRef.current && currentARef.current) {
                transcriptsRef.current.push({
                  question: currentQRef.current,
                  answer: currentARef.current
                });
              }
              currentQRef.current = "";
              currentARef.current = "";
              
              if (isEnding) {
                setTimeout(() => {
                  sessionPromise.then(s => s.close());
                  onInterviewEnd(transcriptsRef.current);
                }, 3000);
              }
            }

            const interrupted = message.serverContent?.interrupted;
            if (interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error(e);
            setError("Voice connection interrupted. Reconnecting...");
          },
          onclose: () => {
            console.log("Session closed");
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          },
          outputAudioTranscription: {},
          inputAudioTranscription: {}
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err: any) {
      setError(err.message || "Failed to start voice session");
    }
  }, [resume, onInterviewEnd, isEnding]);

  useEffect(() => {
    startSession();
    return () => {
      if (sessionRef.current) sessionRef.current.close();
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto glass p-8 rounded-3xl shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Live Interview Session</h2>
        <p className="text-slate-400">Please speak clearly into your microphone.</p>
      </div>

      <VoiceIndicator status={status} />

      {error && (
        <div className="mt-8 p-4 bg-red-900/40 border border-red-500/50 rounded-xl text-red-200 text-center">
          {error}
        </div>
      )}

      <div className="mt-12 flex justify-center">
        <button 
          onClick={() => {
            if (sessionRef.current) sessionRef.current.close();
            onInterviewEnd(transcriptsRef.current);
          }}
          className="px-8 py-3 bg-red-600/20 hover:bg-red-600/40 border border-red-500/40 rounded-full text-red-400 font-medium transition-all"
        >
          End Interview Prematurely
        </button>
      </div>
    </div>
  );
};

export default InterviewSession;
