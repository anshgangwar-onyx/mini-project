
export interface ResumeData {
  name: string;
  email: string;
  domain: string;
  seniority: string;
  skills: string[];
  experienceSummary: string;
}

export interface InterviewExchange {
  question: string;
  answer: string;
}

export interface EvaluationReport {
  technicalKnowledgeScore: number;
  problemSolvingScore: number;
  communicationScore: number;
  confidenceLevel: number;
  industryReadiness: number;
  strengths: string[];
  areasToImprove: string[];
  hiringRecommendation: "Hire" | "Strong Hire" | "Reject" | "Follow-up Needed";
  resumeScore: number;
  atsCompatibility: number;
  skillGaps: string[];
  improvementPlan3Month: string[];
  recommendedCertifications: string[];
  suitableJobRoles: string[];
}

export enum AppState {
  IDLE = 'IDLE',
  PARSING_RESUME = 'PARSING_RESUME',
  INTERVIEW_READY = 'INTERVIEW_READY',
  INTERVIEWING = 'INTERVIEWING',
  GENERATING_REPORT = 'GENERATING_REPORT',
  COMPLETED = 'COMPLETED'
}
