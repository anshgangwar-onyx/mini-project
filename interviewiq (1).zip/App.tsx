
import React, { useState } from 'react';
import { AppState, ResumeData, InterviewExchange, EvaluationReport } from './types';
import { parseResume, generateFinalReport } from './services/geminiService';
import InterviewSession from './components/InterviewSession';
import AssessmentReport from './components/AssessmentReport';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [resumeData, setResumeData] = useState<ResumeData | null>(null);
  const [transcripts, setTranscripts] = useState<InterviewExchange[]>([]);
  const [report, setReport] = useState<EvaluationReport | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      setUploadError("Please upload your resume in PDF format for accurate AI processing.");
      return;
    }

    setUploadError(null);
    setAppState(AppState.PARSING_RESUME);
    setIsLoading(true);

    try {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const arrayBuffer = reader.result as ArrayBuffer;
          const uint8Array = new Uint8Array(arrayBuffer);
          let binary = '';
          const len = uint8Array.byteLength;
          for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(uint8Array[i]);
          }
          const base64 = btoa(binary);

          const data = await parseResume(base64, file.type);
          setResumeData(data);
          setAppState(AppState.INTERVIEW_READY);
        } catch (innerErr: any) {
          console.error("Parsing Error:", innerErr);
          setUploadError("Failed to analyze resume. Please try a different PDF file.");
          setAppState(AppState.IDLE);
        }
      };
      reader.readAsArrayBuffer(file);
    } catch (err) {
      console.error(err);
      setAppState(AppState.IDLE);
    } finally {
      setIsLoading(false);
    }
  };

  const onInterviewEnd = async (results: InterviewExchange[]) => {
    setTranscripts(results);
    setAppState(AppState.GENERATING_REPORT);
    setIsLoading(true);

    try {
      if (resumeData) {
        const finalReport = await generateFinalReport(resumeData, results);
        setReport(finalReport);
        setAppState(AppState.COMPLETED);
      }
    } catch (err) {
      console.error(err);
      setAppState(AppState.INTERVIEW_READY);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-200">
      {/* Top Navigation Bar */}
      <header className="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <span className="text-xl font-bold tracking-tight text-white uppercase">
            Interview<span className="text-blue-500">IQ</span>
          </span>
          <span className="h-4 w-[1px] bg-slate-700 mx-1"></span>
          <span className="text-xs font-semibold text-slate-500 tracking-widest uppercase">Enterprise V1.0</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)]"></div>
          <span className="text-[10px] font-bold text-slate-400 tracking-widest uppercase">Live System Status: Ready</span>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6">
        {appState === AppState.IDLE && (
          <div className="flex flex-col items-center pt-12 md:pt-20 animate-in fade-in slide-in-from-bottom-4 duration-1000">
            {/* Hero Text */}
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
                AI Voice-First Career Assessment
              </h1>
              <p className="text-lg md:text-xl text-slate-400 font-normal leading-relaxed px-4">
                Upload your credentials and experience an adaptive, professional interview driven by next-generation voice intelligence.
              </p>
            </div>

            {/* Upload Section */}
            <div className="w-full max-w-lg">
              {uploadError && (
                <div className="mb-6 p-4 bg-red-500/10 border border-red-500/50 rounded-xl text-red-400 text-center text-sm">
                  {uploadError}
                </div>
              )}

              <div className="bg-[#0f172a] rounded-[2rem] border border-slate-800 p-12 relative overflow-hidden group shadow-2xl">
                <input 
                  type="file" 
                  accept="application/pdf"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer z-10"
                />
                
                <div className="flex flex-col items-center text-center">
                  {/* Circular Upload Icon */}
                  <div className="w-16 h-16 rounded-full bg-blue-600/10 border border-blue-500/20 flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-500">
                    <svg className="w-8 h-8 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                    </svg>
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-3">Upload Your Resume</h3>
                  <p className="text-slate-400 text-sm mb-10 px-4">
                    Upload your resume (PDF format) to start the interview process.
                  </p>

                  {/* Inner Dashed Dropzone Area */}
                  <div className="w-full h-48 border-2 border-dashed border-slate-800 rounded-2xl flex flex-col items-center justify-center group-hover:border-blue-500/40 transition-colors duration-500 bg-[#020617]/40">
                    <svg className="w-12 h-12 text-slate-700 group-hover:text-blue-500/40 transition-colors duration-500 mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                </div>
              </div>
              <p className="text-center mt-6 text-slate-500 text-xs tracking-widest uppercase">Clinical • Professional • Accurate</p>
            </div>
          </div>
        )}

        {(appState === AppState.PARSING_RESUME || appState === AppState.GENERATING_REPORT) && (
          <div className="max-w-md mx-auto py-24 text-center">
            <div className="relative w-24 h-24 mx-auto mb-10">
              <div className="absolute inset-0 border-4 border-blue-500/10 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
            <h2 className="text-2xl font-bold text-white mb-4 tracking-tight uppercase">
              {appState === AppState.PARSING_RESUME ? 'Analyzing Profile' : 'Synthesizing Data'}
            </h2>
            <p className="text-slate-500 text-sm max-w-[280px] mx-auto leading-relaxed">
              Our enterprise intelligence system is processing your credentials for optimal assessment.
            </p>
          </div>
        )}

        {appState === AppState.INTERVIEW_READY && resumeData && (
          <div className="max-w-xl mx-auto py-20 animate-in zoom-in duration-500">
            <div className="bg-[#0f172a] rounded-[2.5rem] border border-slate-800 p-12 text-center shadow-2xl">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl mx-auto mb-8 flex items-center justify-center text-4xl shadow-xl shadow-blue-500/20">
                <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">Verification Complete</h2>
              <p className="text-slate-400 mb-10 leading-relaxed">
                Candidate <span className="text-white font-semibold">{resumeData.name}</span> identified for <span className="text-white font-semibold">{resumeData.domain}</span> assessment.
              </p>
              <div className="flex flex-col gap-4">
                <button 
                  onClick={() => setAppState(AppState.INTERVIEWING)}
                  className="w-full py-5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-lg rounded-2xl transition-all active:scale-95 shadow-lg shadow-blue-500/25 uppercase tracking-widest"
                >
                  Initialize Voice Interview
                </button>
                <button 
                  onClick={() => {
                     setResumeData(null);
                     setAppState(AppState.IDLE);
                  }}
                  className="w-full py-4 text-slate-500 hover:text-white transition-colors text-sm uppercase tracking-widest"
                >
                  Restart Application
                </button>
              </div>
            </div>
          </div>
        )}

        {appState === AppState.INTERVIEWING && resumeData && (
          <div className="py-12">
            <InterviewSession resume={resumeData} onInterviewEnd={onInterviewEnd} />
          </div>
        )}

        {appState === AppState.COMPLETED && report && (
          <div className="py-12">
            <AssessmentReport report={report} />
          </div>
        )}
      </main>
      
      {/* Subtle background glow */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-blue-500/5 blur-[120px] rounded-full -z-10 pointer-events-none"></div>
    </div>
  );
};

export default App;
