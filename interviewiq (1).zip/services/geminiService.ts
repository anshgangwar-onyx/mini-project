
import { GoogleGenAI, Type } from "@google/genai";
import { ResumeData, EvaluationReport, InterviewExchange } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const parseResume = async (fileBase64: string, mimeType: string): Promise<ResumeData> => {
  // Only application/pdf is supported for document inlineData in Gemini generateContent
  if (mimeType !== 'application/pdf') {
    throw new Error(`Unsupported MIME type: ${mimeType}. Please use PDF.`);
  }

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [
      {
        inlineData: {
          data: fileBase64,
          mimeType: mimeType
        }
      },
      {
        text: "Extract structured data from this resume. Be accurate. Do not hallucinate. Detect domain and seniority levels carefully."
      }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          email: { type: Type.STRING },
          domain: { type: Type.STRING },
          seniority: { type: Type.STRING },
          skills: { type: Type.ARRAY, items: { type: Type.STRING } },
          experienceSummary: { type: Type.STRING }
        },
        required: ["name", "domain", "seniority", "skills"]
      }
    }
  });

  if (!response.text) {
    throw new Error("Empty response from AI while parsing resume.");
  }

  return JSON.parse(response.text) as ResumeData;
};

export const generateFinalReport = async (
  resume: ResumeData, 
  transcripts: InterviewExchange[]
): Promise<EvaluationReport> => {
  const transcriptString = transcripts.map(t => `Q: ${t.question}\nA: ${t.answer}`).join("\n\n");
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `
      Analyze this interview transcript and resume to provide a comprehensive career assessment.
      
      RESUME:
      ${JSON.stringify(resume)}
      
      TRANSCRIPT:
      ${transcriptString}
      
      Provide a highly detailed, professional, and accurate evaluation.
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          technicalKnowledgeScore: { type: Type.NUMBER },
          problemSolvingScore: { type: Type.NUMBER },
          communicationScore: { type: Type.NUMBER },
          confidenceLevel: { type: Type.NUMBER },
          industryReadiness: { type: Type.NUMBER },
          strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
          areasToImprove: { type: Type.ARRAY, items: { type: Type.STRING } },
          hiringRecommendation: { type: Type.STRING },
          resumeScore: { type: Type.NUMBER },
          atsCompatibility: { type: Type.NUMBER },
          skillGaps: { type: Type.ARRAY, items: { type: Type.STRING } },
          improvementPlan3Month: { type: Type.ARRAY, items: { type: Type.STRING } },
          recommendedCertifications: { type: Type.ARRAY, items: { type: Type.STRING } },
          suitableJobRoles: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["technicalKnowledgeScore", "hiringRecommendation"]
      }
    }
  });

  return JSON.parse(response.text || "{}") as EvaluationReport;
};
